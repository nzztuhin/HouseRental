-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 25, 2020 at 05:51 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `houserental`
--

-- --------------------------------------------------------

--
-- Table structure for table `property_table`
--

CREATE TABLE `property_table` (
  `PropertyID` int(5) NOT NULL,
  `Property_name` varchar(20) NOT NULL,
  `PropertyOwnerName` varchar(30) NOT NULL,
  `Property_Type` varchar(20) NOT NULL,
  `Floor` int(5) NOT NULL,
  `Area` varchar(20) NOT NULL,
  `Rooms` int(5) NOT NULL,
  `Location` varchar(20) NOT NULL,
  `Price` int(20) NOT NULL,
  `Status` varchar(20) NOT NULL DEFAULT 'Active',
  `photo` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `property_table`
--

INSERT INTO `property_table` (`PropertyID`, `Property_name`, `PropertyOwnerName`, `Property_Type`, `Floor`, `Area`, `Rooms`, `Location`, `Price`, `Status`, `photo`) VALUES
(1, 'Apartment', 'Tuhin Zaman', 'House', 1, '1330 sqft', 4, 'Mirpur-14', 25000, 'Active', ''),
(2, 'Shop1', 'Abir Rahman', 'Shop', 2, '500 sqft', 2, 'Uttara', 30000, 'Active', ''),
(3, 'Office1', 'Abul Kalam', 'Office', 4, '1200 sqft', 6, 'Banani', 100000, 'Active', ''),
(6, 'Office2', 'tanjim', 'Office', 2, '1200 sqft', 4, 'Gulshan', 50000, 'Active', 'kissclipart-house-clipart-house-clip-art-56de1ca9c21c68eb.jpg'),
(7, 'shop3', 'tanjim', 'Shop', 3, '1200 sqft', 2, 'mirpur', 12500, 'Active', 'c8637ca0fe5cc0faf3bea70c7336a627.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `reg_table`
--

CREATE TABLE `reg_table` (
  `Id` int(20) NOT NULL,
  `First_name` varchar(50) NOT NULL,
  `Last_name` varchar(50) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `userType` int(11) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Mobile_number` varchar(50) NOT NULL,
  `active_status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reg_table`
--

INSERT INTO `reg_table` (`Id`, `First_name`, `Last_name`, `Username`, `Password`, `userType`, `Email`, `Mobile_number`, `active_status`) VALUES
(1, 'Abir', 'Rahim', 'abir', '81dc9bdb52d04dc20036dbd8313ed055', 2, 'abir@gmail.com', '01759446954', 0),
(5, 'Karim', 'Miah', 'karim', '81dc9bdb52d04dc20036dbd8313ed055', 3, 'karin@yahoo.com', '0169875825', 0),
(6, 'zabir', 'abdullah', 'zabir', 'd74a214501c1c40b2c77e995082f3587', 2, 'zabir@yahoo.com', '0156698754', 0),
(7, 'Noman', 'abdullah', 'Noman', '81dc9bdb52d04dc20036dbd8313ed055', 3, 'noman@yahoo.com', '0169dd8754', 1),
(8, 'Tuhin', 'Zaman', 'tuhin', '81dc9bdb52d04dc20036dbd8313ed055', 1, 'nzztuhin@gmail.com', '01521334929', 1),
(10, 'Tanjmul', 'Islam', 'tanjim', '81dc9bdb52d04dc20036dbd8313ed055', 2, 'tanjim@gmail.com', '0158897568', 1),
(11, 'tusher', 'hasan', 'tusher', 'e2fc714c4727ee9395f324cd2e7f331f', 2, 'tusher@gmail.com', '01524365458', 0);

-- --------------------------------------------------------

--
-- Table structure for table `rental_table`
--

CREATE TABLE `rental_table` (
  `r_id` int(200) NOT NULL,
  `Rant_taker` varchar(200) NOT NULL,
  `property_name` varchar(200) NOT NULL,
  `PropertyOwner` varchar(200) NOT NULL,
  `Property_Type` varchar(200) NOT NULL,
  `Area` varchar(200) NOT NULL,
  `Location` varchar(200) NOT NULL,
  `Price` varchar(200) NOT NULL,
  `From_date` date NOT NULL,
  `To_date` date NOT NULL,
  `status` varchar(200) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rental_table`
--

INSERT INTO `rental_table` (`r_id`, `Rant_taker`, `property_name`, `PropertyOwner`, `Property_Type`, `Area`, `Location`, `Price`, `From_date`, `To_date`, `status`) VALUES
(1, 'Noman', 'Office2', 'tanjim', 'Office', '1200 sqft', 'Gulshan', '50000', '2020-09-26', '2020-11-19', 'pending'),
(2, 'Noman', 'shop3', 'tanjim', 'Shop', '1200 sqft', 'mirpur', '12500', '2020-10-01', '2020-10-08', 'Aceepted');

-- --------------------------------------------------------

--
-- Table structure for table `user_types`
--

CREATE TABLE `user_types` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_types`
--

INSERT INTO `user_types` (`id`, `name`) VALUES
(1, 'Admin'),
(2, 'Property Owner'),
(3, 'Rent Taker');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `property_table`
--
ALTER TABLE `property_table`
  ADD PRIMARY KEY (`PropertyID`);

--
-- Indexes for table `reg_table`
--
ALTER TABLE `reg_table`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `Username` (`Username`),
  ADD KEY `usertypes1users` (`userType`);

--
-- Indexes for table `rental_table`
--
ALTER TABLE `rental_table`
  ADD PRIMARY KEY (`r_id`);

--
-- Indexes for table `user_types`
--
ALTER TABLE `user_types`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `property_table`
--
ALTER TABLE `property_table`
  MODIFY `PropertyID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `reg_table`
--
ALTER TABLE `reg_table`
  MODIFY `Id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `rental_table`
--
ALTER TABLE `rental_table`
  MODIFY `r_id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_types`
--
ALTER TABLE `user_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
